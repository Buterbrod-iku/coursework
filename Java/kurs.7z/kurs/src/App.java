import java.util.*;
import java.io.*;

// создаём класс для клиентов
class Client
{
    String name;
    String pol;
    int year;
    String sity;
    String diagnosis;

    static void PrintClient(ArrayList<Client> people) {
        for (int i = 0; i < people.size(); i++)
            {
                System.out.printf("Ф.И.О: " + people.get(i).name + "\nПол: " + people.get(i).pol + "\nГод: " + people.get(i).year + "\nГород: " + people.get(i).sity + "\nДиагноз: " + people.get(i).diagnosis + "\n");
                System.out.println("--------");
            }
        
    }

    static void IfNotBarnaulPrint(ArrayList<Client> people) {
        for (int i = 0; i < people.size(); i++)
        {
            if (!people.get(i).sity.equals("Барнаул")) {
                System.out.printf("Ф.И.О: " + people.get(i).name + "\tГород: " + people.get(i).sity + "\n");
            }
        }
    }

    static void InputHighAgeInFile(FileWriter fout, ArrayList<Client> people, int ageNew) throws IOException{
        for (int i = 0; i < people.size(); i++)
        {
            if (people.get(i).year >= ageNew) {
                fout.write(people.get(i).name + "\n" + people.get(i).year + "\n" + people.get(i).diagnosis + "\n");
            }
        }
        fout.flush();
        fout.close();
    }

    static void HigtAgeInFile(FileWriter inputFin, FileReader printFout) throws IOException{
        Scanner Reader1 = new Scanner(printFout);

        // добавляем >= age в исходный файл
        while (Reader1.hasNextLine()) {
            String data = Reader1.nextLine();
            inputFin.write(data + "\n");
        }
        inputFin.flush();
    }

    static void PrintRes(FileReader fin){
        Scanner Reader1 = new Scanner(fin);

        while (Reader1.hasNextLine()) {
            String data = Reader1.nextLine();
            System.out.printf(data + "\n");
        }
    }

    static void DeletePeopleIfNotBarnaulWithFile(ArrayList<Client> people, FileWriter inputFinalFin) throws IOException{
        for (int i = 0; i < people.size(); i++)
        {
            if (people.get(i).sity.equals("Барнаул")) {
                inputFinalFin.append(people.get(i).name + "\n" + people.get(i).pol + "\n" + people.get(i).year + "\n" + people.get(i).sity + "\n" + people.get(i).diagnosis + "\n");
            }
        }
        inputFinalFin.flush();
        inputFinalFin.close();
    }

    static void ClearFile(FileWriter inputFinalFin){
        PrintWriter clearFinalFin = new PrintWriter(inputFinalFin);
        clearFinalFin.print("");
        clearFinalFin.flush();
    }

    static void RemakeDiagnos(ArrayList<Client> people){
        System.out.printf("Изменить диагноз? д/н" + "\n");
        Scanner testNum = new Scanner(System.in);
        char test = testNum.nextLine().charAt(0);
        if (test == 'д') {
            // перезаписываем диагноз
            App.Remake(people);
            System.out.printf("Изменить диагноз? д/н" + "\n");
            test = testNum.nextLine().charAt(0);
        }
    }

    static ArrayList<Client> ConsoleWritePeople(){
        Scanner inputInt = new Scanner(System.in);

        System.out.println("Сколько пациентов");
        int res = inputInt.nextInt();

        ArrayList<Client> people = new ArrayList<Client>();
        // заполняем массив клиентов
        for (int i = 0; i < res; i ++)
        {
            Scanner inputText = new Scanner(System.in);
            Client first = new Client();

            System.out.print("Введите Ф.И.О. - ");
            first.name = inputText.nextLine();

            System.out.print("Введите пол - ");
            first.pol = inputText.nextLine();

            System.out.print("Введите возраст - ");
            first.year = inputInt.nextInt();

            System.out.print("Введите город - ");
            first.sity = inputText.nextLine();

            System.out.print("Введите диагноз - ");
            first.diagnosis = inputText.nextLine();

            people.add(first);
        }

        return people;
    }

    static void WriteInFile(ArrayList<Client> people, FileWriter fout) throws IOException{
        for (int i = 0; i < people.size(); i++)
        {
            fout.write(people.get(i).name + "\n" + people.get(i).pol + "\n" + people.get(i).year + "\n" + people.get(i).sity + "\n" + people.get(i).diagnosis + "\n\n");
        }
        fout.flush();
        fout.close();
    }
};

public class App {
    public static void Remake(ArrayList<Client> people){
        Scanner resetDiagnosis = new Scanner(System.in);
        String fio = resetDiagnosis.nextLine();
        String diagnosisNew = resetDiagnosis.nextLine();

        for (int i = 0; i < people.size(); i++)
        {
            if (fio.equals(people.get(i).name)) {
                people.get(i).diagnosis = diagnosisNew;
            } else {
                System.out.println("Пациент не найден");
            }
        }
    }

    public static void main(String[] args) throws Exception {
        
        System.out.println( "Заполнить данные пациентов");

        ArrayList<Client> people = new ArrayList<Client>();

        int age = 0;

        if (new File("./src/test.txt").exists()){
            try(FileReader fin = new FileReader("./src/test.txt")){
                people = Client.ConsoleWritePeople();
                Client.WriteInFile(people, new FileWriter("./src/test.txt"));
            }catch(IOException ex){
                System.out.println(ex.getMessage());
            }
        } else{
            FileReader fin = new FileReader("./src/test.txt");
            try(fin){
                people = Client.ConsoleWritePeople();
                Client.WriteInFile(people, new FileWriter("./src/test.txt"));
            }catch(IOException ex){
                System.out.println(ex.getMessage());
            }
        }

        while(true){
            System.out.println( "1. Выдать на экран содержимое файла\n" +
                                "2. Выдать на экран список всех иногородних пациентов\n" +
                                "3. Создать файл пациентов больше заданого возраста\n" +
                                "4. Распечатать файл пациентов больше заданого возраста\n" +
                                "5. Добавить пациентов больше заданого возраста в исходный файл\n" +
                                "6. Удалить все элементы записи инногородних пациентов\n" +
                                "7. Изменить диагноз у определённого пациетна\n" +
                                "8. Выход"
            );
            Scanner numberFunction = new Scanner(System.in);
            String numberFunctionInput = numberFunction.nextLine();
            switch(numberFunctionInput){
                case("1"):
                    // выводим, что заполнили
                    Client.PrintClient(people);
                    break;
                case("2"):
                    // Проверка на инногородних и выводим их
                    Client.IfNotBarnaulPrint(people);
                    break;
                case("3"):
                    // запрашиваем возраст
                    System.out.print("Введите возраст (выведутся пациенты больше или такому же значению) - ");
                    Scanner ageNum = new Scanner(System.in);
                    age = ageNum.nextInt();
                    if (new File("./src/res.txt").exists()){
                        try(FileWriter fin = new FileWriter("./src/res.txt")){
                            // записываем в другой файл >= age
                            Client.InputHighAgeInFile(new FileWriter("./src/res.txt"), people, age);
                        }catch(IOException ex){
                            System.out.println(ex.getMessage());
                        } 
                    } else{
                        FileWriter fin = new FileWriter("./src/res.txt");
                        try(fin){
                            // записываем в другой файл >= age
                            Client.InputHighAgeInFile(new FileWriter("./src/res.txt"), people, age);
                        }catch(IOException ex){
                            System.out.println(ex.getMessage());
                        }
                    }
                    break;
                case("4"):
                    if (new File("./src/res.txt").exists()){
                        try(FileWriter fin = new FileWriter("./src/res.txt")){
                            Client.PrintRes(new FileReader("./src/res.txt"));
                        }catch(IOException ex){
                            System.out.println(ex.getMessage());
                        } 
                    } else{
                        System.out.println("Файл не найден");
                    }
                    break;
                case("5"):
                    if (new File("./src/test.txt").exists()){
                        try(FileReader fin = new FileReader("./src/test.txt")){
                            // добавляем >= age в исходный файл
                            Client.HigtAgeInFile(new FileWriter("./src/test.txt"), new FileReader("res.txt"));
                        }catch(IOException ex){
                            System.out.println(ex.getMessage());
                        }
                    } else{
                        System.out.println("Файл не найден");
                    }
                    break;
                case("6"):
                    if (new File("./src/test.txt").exists()){
                        try(FileReader fin = new FileReader("./src/test.txt")){
                            // отчищаем файл
                            Client.ClearFile(new FileWriter("./src/test.txt"));
                            // удаляем записи инногородних
                            Client.DeletePeopleIfNotBarnaulWithFile(people, new FileWriter("./src/test.txt"));
                        }catch(IOException ex){
                            System.out.println(ex.getMessage());
                        }
                    } else{
                        System.out.println("Файл не найден");
                    }
                    break;
                case("7"):
                    if (new File("./src/test.txt").exists()){
                        try(FileReader fin = new FileReader("./src/test.txt")){
                            // отчищаем файл
                            Client.ClearFile(new FileWriter("./src/test.txt"));
                            // надо ли перезаписывать диагноз
                            Client.RemakeDiagnos(people);
                            Client.WriteInFile(people, new FileWriter("./src/test.txt"));
                        }catch(IOException ex){
                            System.out.println(ex.getMessage());
                        }
                    } else{
                        System.out.println("Файл не найден");
                    }
                    break;
                case("8"):
                    System.exit(0);
                    break;
                default:
                    System.out.println("Недопустимое значение!"); 
            }
        }
    }
}
